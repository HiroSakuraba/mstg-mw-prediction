from __future__ import annotations

"""MSTG galactic test pipeline for SPARC and CDG-2.

This module upgrades the earlier galactic scaffold into a working analysis script
that can:

1. Load official SPARC ``*_rotmod.dat`` files.
2. Optionally merge official SPARC Table1 metadata from ``SPARC_Lelli2016c.mrt``
   or user-supplied CSV/TSV/JSON metadata.
3. Construct baryonic rotation curves using gas, disk, and bulge components.
4. Fit universal branch parameters for the galactic branches M0, MA, MB, MAB,
   and MC.
5. Produce fit summaries, residual diagnostics, BTFR checks, and RAR plots.
6. Retain a lightweight CDG-2 likelihood implementation for the Stage-1 branch
   discriminator.
7. Benchmark multiple Method C gate observables and swap between them without
   changing the rest of the fitting stack.

The Method A/B/C kernels here are operational galactic approximants tied to the
current manuscript logic. They are not the final word, but they are no longer
free-form placeholders.
"""

import abc
import argparse
import csv
import json
import math
import re
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import minimize

# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------

G_KPC_KMS2_PER_MSUN = 4.30091e-6  # kpc (km/s)^2 / Msun
ACCEL_KMS2_PER_KPC_TO_MPS2 = 1.0e6 / 3.085677581491367e19
G_SI = 6.67430e-11
KPC_M = 3.085677581491367e19
MSUN_KG = 1.98847e30
LAMBDA_BARE_OVER_GAMMA_W = 6.47e-3 / 3.89e-2
RNG_MEMORY_INDEX_N = 0.6

DEFAULT_UPSILON_DISK = 0.5
DEFAULT_UPSILON_BULGE = 0.7
DEFAULT_GAS_HELIUM_FACTOR = 1.33

METHOD_C_GATE_MODES = (
    "constant",
    "sb_eff",
    "sb_disk0",
    "sigma_bar_eff",
    "sigma_star_eff",
    "sigma_gas_eff",
    "gbar_2rd",
    "gbar_22rd",
    "baryon_compactness",
    "gas_fraction",
    "gas_to_stellar",
    "stellar_fraction",
    "disk_dominance_22rd",
)

PIPELINE_CONFIG: Dict[str, Any] = {
    "mc_gate_mode": "sb_eff",
    "mc_comp_mode": "gas_to_stellar",
    "mc_morph_mode": "baryon_compactness",
    "mc_obs_stats": {},
    "method_b_kernel": "disk_aware_v2",
}


# -----------------------------------------------------------------------------
# Dataclasses
# -----------------------------------------------------------------------------


@dataclass(frozen=True)
class UniversalParams:
    beta: float = 0.0
    r_ir_kpc: float = 5.0
    theta_c: Tuple[float, ...] = (0.0,)
    u0_sq_over_c2_si: float = 1.0e-30
    rho_lambda_max_si: float = 6.0e-27
    v_screen_kms: float = 1.0e6  # Default = no suppression (MC4 only)

    def vacuum_density_si(self) -> float:
        return self.beta * self.u0_sq_over_c2_si

    def check_cosmology_fence(self) -> None:
        if self.vacuum_density_si() > self.rho_lambda_max_si:
            raise ValueError(
                f"Cosmology fence violated: rho_vac={self.vacuum_density_si():.3e} > "
                f"rho_lambda_max={self.rho_lambda_max_si:.3e}"
            )


@dataclass(frozen=True)
class GalaxyNuisance:
    upsilon_disk: float = DEFAULT_UPSILON_DISK
    upsilon_bulge: float = DEFAULT_UPSILON_BULGE
    distance_mpc: float = np.nan
    inclination_deg: float = np.nan
    r_eff_kpc: float = np.nan
    xi: float = 0.5
    chi_env_obs: float = 1.0
    sigma_int_scatter: float = 0.0


@dataclass(frozen=True)
class SPARCGalaxy:
    name: str
    radius_kpc: np.ndarray
    v_obs_kms: np.ndarray
    v_err_kms: np.ndarray
    v_gas_kms: np.ndarray
    v_disk_kms: np.ndarray
    v_bulge_kms: np.ndarray
    sb_disk_lsun_pc2: np.ndarray
    sb_bulge_lsun_pc2: np.ndarray
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        arrays = (
            self.radius_kpc,
            self.v_obs_kms,
            self.v_err_kms,
            self.v_gas_kms,
            self.v_disk_kms,
            self.v_bulge_kms,
            self.sb_disk_lsun_pc2,
            self.sb_bulge_lsun_pc2,
        )
        shapes = {arr.shape for arr in arrays}
        if len(shapes) != 1:
            raise ValueError(f"SPARC arrays must share a common shape for {self.name}")
        if self.radius_kpc.ndim != 1:
            raise ValueError(f"SPARC arrays must be 1D for {self.name}")

    @property
    def q_flag(self) -> Optional[int]:
        val = self.metadata.get("Q")
        if val is None or (isinstance(val, float) and np.isnan(val)):
            return None
        return int(val)

    @property
    def distance_mpc(self) -> float:
        for key in ("distance_mpc", "D"):
            if key in self.metadata and pd.notna(self.metadata[key]):
                return float(self.metadata[key])
        return np.nan


@dataclass(frozen=True)
class CDG2Data:
    velocities_kms: np.ndarray
    errors_kms: np.ndarray
    stellar_mass_msun: float
    name: str = "CDG-2"

    def __post_init__(self) -> None:
        if self.velocities_kms.shape != self.errors_kms.shape:
            raise ValueError("velocities_kms and errors_kms must have matching shape")
        if self.velocities_kms.ndim != 1:
            raise ValueError("CDG-2 arrays must be one-dimensional")


@dataclass
class FitResult:
    branch: str
    params: UniversalParams
    objective: float
    success: bool
    message: str
    n_galaxies: int
    n_points: int
    reduced_chi2: float
    aic: float
    bic: float
    diagnostics: Dict[str, float] = field(default_factory=dict)


# -----------------------------------------------------------------------------
# Parsers and I/O
# -----------------------------------------------------------------------------


TABLE1_SPECS: Tuple[Tuple[str, int, int, str], ...] = (
    ("Galaxy", 0, 11, "str"),
    ("T", 11, 13, "int"),
    ("D", 13, 19, "float"),
    ("e_D", 19, 24, "float"),
    ("f_D", 24, 26, "int"),
    ("Inc", 26, 30, "float"),
    ("e_Inc", 30, 34, "float"),
    ("L36", 34, 41, "float"),
    ("e_L36", 41, 48, "float"),
    ("Reff", 48, 53, "float"),
    ("SBeff", 53, 61, "float"),
    ("Rdisk", 61, 66, "float"),
    ("SBdisk0", 66, 74, "float"),
    ("MHI", 74, 81, "float"),
    ("RHI", 81, 86, "float"),
    ("Vflat", 86, 91, "float"),
    ("e_Vflat", 91, 96, "float"),
    ("Q", 96, 99, "int"),
    ("Ref", 99, 113, "str"),
)


def _coerce_field(text: str, kind: str) -> Any:
    raw = text.strip()
    if raw == "":
        return np.nan if kind != "str" else ""
    if kind == "str":
        return raw
    if kind == "int":
        try:
            return int(raw)
        except ValueError:
            return np.nan
    if kind == "float":
        try:
            return float(raw)
        except ValueError:
            return np.nan
    raise ValueError(f"Unsupported field kind: {kind}")



def parse_table1_mrt(path: Path) -> Dict[str, Dict[str, Any]]:
    """Parse the official SPARC ``SPARC_Lelli2016c.mrt`` file.

    In practice the distributed MRT rows are easiest to read by whitespace
    tokenization once header lines are skipped. We keep a fixed-width fallback
    for safety, but prefer the token route because it preserves the intended
    columns for the public table shipped with SPARC.
    """
    records: Dict[str, Dict[str, Any]] = {}
    with path.open("r", encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            if not line.strip():
                continue
            if line.startswith("Title:") or "Byte-by-byte Description" in line:
                continue
            if set(line.strip()) <= {"-", "="}:
                continue
            if "Galaxy Name" in line or "References for HI" in line or line.startswith("Note "):
                continue
            stripped = line.strip()
            if not stripped or stripped.startswith(("Authors:", "Table:", "Bytes", "Byte", "Format", "Units", "Label", "Explanations")):
                continue

            tokens = stripped.split()
            if len(tokens) == 19:
                galaxy = tokens[0]
                row = {
                    "distance_mpc": _coerce_field(tokens[2], "float"),
                    "distance_err_mpc": _coerce_field(tokens[3], "float"),
                    "distance_method": _coerce_field(tokens[4], "int"),
                    "inclination_deg": _coerce_field(tokens[5], "float"),
                    "inclination_err_deg": _coerce_field(tokens[6], "float"),
                    "luminosity_36_1e9lsun": _coerce_field(tokens[7], "float"),
                    "luminosity_36_err_1e9lsun": _coerce_field(tokens[8], "float"),
                    "r_eff_kpc": _coerce_field(tokens[9], "float"),
                    "sb_eff_lsun_pc2": _coerce_field(tokens[10], "float"),
                    "r_disk_kpc": _coerce_field(tokens[11], "float"),
                    "sb_disk0_lsun_pc2": _coerce_field(tokens[12], "float"),
                    "mhi_1e9msun": _coerce_field(tokens[13], "float"),
                    "r_hi_kpc": _coerce_field(tokens[14], "float"),
                    "vflat_kms": _coerce_field(tokens[15], "float"),
                    "vflat_err_kms": _coerce_field(tokens[16], "float"),
                    "Q": _coerce_field(tokens[17], "int"),
                    "reference": tokens[18],
                    "hubble_type_code": _coerce_field(tokens[1], "int"),
                }
                records[galaxy] = row
                continue

            row = {name: _coerce_field(line[start:end], kind) for name, start, end, kind in TABLE1_SPECS}
            galaxy = str(row["Galaxy"]).strip()
            if not galaxy:
                continue
            if all(pd.isna(row.get(k, np.nan)) for k in ("D", "Inc", "L36", "MHI", "Vflat", "Q")):
                continue
            records[galaxy] = {
                "distance_mpc": row["D"],
                "distance_err_mpc": row["e_D"],
                "distance_method": row["f_D"],
                "inclination_deg": row["Inc"],
                "inclination_err_deg": row["e_Inc"],
                "luminosity_36_1e9lsun": row["L36"],
                "luminosity_36_err_1e9lsun": row["e_L36"],
                "r_eff_kpc": row["Reff"],
                "sb_eff_lsun_pc2": row["SBeff"],
                "r_disk_kpc": row["Rdisk"],
                "sb_disk0_lsun_pc2": row["SBdisk0"],
                "mhi_1e9msun": row["MHI"],
                "r_hi_kpc": row["RHI"],
                "vflat_kms": row["Vflat"],
                "vflat_err_kms": row["e_Vflat"],
                "Q": row["Q"],
                "reference": row["Ref"],
                "hubble_type_code": row["T"],
            }
    if not records:
        raise ValueError(f"No Table1 rows were parsed from {path}")
    return records

def parse_metadata_table(path: Optional[Path]) -> Dict[str, Dict[str, Any]]:
    if path is None:
        return {}
    suffix = path.suffix.lower()
    if suffix == ".mrt":
        return parse_table1_mrt(path)
    if suffix == ".json":
        payload = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(payload, dict):
            return {str(k): dict(v) for k, v in payload.items()}
        if isinstance(payload, list):
            out: Dict[str, Dict[str, Any]] = {}
            for row in payload:
                name = row.get("name") or row.get("galaxy")
                if name:
                    out[str(name)] = dict(row)
            return out
        raise ValueError(f"Unsupported JSON metadata structure in {path}")
    sep = "\t" if suffix in {".tsv", ".tab"} else ","
    df = pd.read_csv(path, sep=sep)
    df = _normalize_dataframe_columns(df)
    if "name" not in df.columns:
        raise ValueError(f"Metadata file {path} needs a galaxy/name column")
    records: Dict[str, Dict[str, Any]] = {}
    for row in df.to_dict(orient="records"):
        name = str(row["name"]).strip()
        if name:
            records[name] = row
    return records


HEADER_DISTANCE_RE = re.compile(r"Distance\s*=\s*([0-9.+-Ee]+)\s*Mpc", re.IGNORECASE)


def parse_rotmod_file(path: Path, metadata: Mapping[str, Dict[str, Any]] | None = None) -> SPARCGalaxy:
    metadata = metadata or {}
    rows: List[List[float]] = []
    distance_mpc = np.nan
    with path.open("r", encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.startswith("#"):
                m = HEADER_DISTANCE_RE.search(stripped)
                if m:
                    distance_mpc = float(m.group(1))
                continue
            parts = stripped.split()
            if len(parts) < 8:
                continue
            try:
                rows.append([float(x) for x in parts[:8]])
            except ValueError:
                continue
    if not rows:
        raise ValueError(f"No SPARC rows parsed from {path}")
    arr = np.asarray(rows, dtype=float)
    name = path.name.replace("_rotmod.dat", "")
    meta = dict(metadata.get(name, {}))
    if pd.isna(meta.get("distance_mpc", np.nan)) and pd.notna(distance_mpc):
        meta["distance_mpc"] = distance_mpc
    return SPARCGalaxy(
        name=name,
        radius_kpc=arr[:, 0],
        v_obs_kms=arr[:, 1],
        v_err_kms=arr[:, 2],
        v_gas_kms=arr[:, 3],
        v_disk_kms=arr[:, 4],
        v_bulge_kms=arr[:, 5],
        sb_disk_lsun_pc2=arr[:, 6],
        sb_bulge_lsun_pc2=arr[:, 7],
        metadata=meta,
    )



def load_sparc_sample(rotmod_dir: Path, metadata_path: Optional[Path] = None) -> List[SPARCGalaxy]:
    metadata = parse_metadata_table(metadata_path)
    files = sorted(rotmod_dir.glob("*_rotmod.dat"))
    if not files:
        raise ValueError(f"No *_rotmod.dat files found under {rotmod_dir}")
    sample = [parse_rotmod_file(path, metadata) for path in files]
    return sample


# -----------------------------------------------------------------------------
# Derived galaxy quantities
# -----------------------------------------------------------------------------



def signed_square(values: np.ndarray) -> np.ndarray:
    return np.sign(values) * values**2



def baryonic_v2_kms2(galaxy: SPARCGalaxy, nuisance: GalaxyNuisance) -> np.ndarray:
    return (
        signed_square(galaxy.v_gas_kms)
        + nuisance.upsilon_disk * galaxy.v_disk_kms**2
        + nuisance.upsilon_bulge * galaxy.v_bulge_kms**2
    )



def baryonic_vcirc_kms(galaxy: SPARCGalaxy, nuisance: GalaxyNuisance) -> np.ndarray:
    return np.sqrt(np.clip(baryonic_v2_kms2(galaxy, nuisance), 0.0, None))



def integrate_luminosity_from_profile(radius_kpc: np.ndarray, sb_lsun_pc2: np.ndarray) -> float:
    positive = np.isfinite(radius_kpc) & np.isfinite(sb_lsun_pc2) & (radius_kpc >= 0.0) & (sb_lsun_pc2 >= 0.0)
    if positive.sum() < 2:
        return np.nan
    r_pc = radius_kpc[positive] * 1.0e3
    sigma = sb_lsun_pc2[positive]
    integrand = 2.0 * np.pi * sigma * r_pc
    lum_lsun = float(np.trapezoid(integrand, r_pc))
    return lum_lsun



def stellar_luminosity_components(galaxy: SPARCGalaxy) -> Tuple[float, float]:
    l_disk = integrate_luminosity_from_profile(galaxy.radius_kpc, galaxy.sb_disk_lsun_pc2)
    l_bulge = integrate_luminosity_from_profile(galaxy.radius_kpc, galaxy.sb_bulge_lsun_pc2)
    return l_disk, l_bulge



def stellar_mass_msun(galaxy: SPARCGalaxy, nuisance: GalaxyNuisance) -> float:
    l_disk, l_bulge = stellar_luminosity_components(galaxy)
    if np.isfinite(l_disk) or np.isfinite(l_bulge):
        return float(
            np.nan_to_num(nuisance.upsilon_disk * l_disk, nan=0.0)
            + np.nan_to_num(nuisance.upsilon_bulge * l_bulge, nan=0.0)
        )
    total_l36 = galaxy.metadata.get("luminosity_36_1e9lsun")
    if total_l36 is None or pd.isna(total_l36):
        return np.nan
    # Fallback when profile decomposition is unavailable.
    return float(DEFAULT_UPSILON_DISK * float(total_l36) * 1.0e9)



def gas_mass_msun(galaxy: SPARCGalaxy, helium_factor: float = DEFAULT_GAS_HELIUM_FACTOR) -> float:
    mhi = galaxy.metadata.get("mhi_1e9msun")
    if mhi is None or pd.isna(mhi):
        return np.nan
    return float(helium_factor * float(mhi) * 1.0e9)



def baryonic_mass_msun(galaxy: SPARCGalaxy, nuisance: GalaxyNuisance) -> float:
    mstar = stellar_mass_msun(galaxy, nuisance)
    mgas = gas_mass_msun(galaxy)
    if not np.isfinite(mstar) and not np.isfinite(mgas):
        return np.nan
    return float(np.nan_to_num(mstar, nan=0.0) + np.nan_to_num(mgas, nan=0.0))



def estimate_vflat_kms(radius_kpc: np.ndarray, velocity_kms: np.ndarray) -> float:
    valid = np.isfinite(radius_kpc) & np.isfinite(velocity_kms) & (radius_kpc > 0)
    r = radius_kpc[valid]
    v = velocity_kms[valid]
    if v.size == 0:
        return np.nan
    if v.size <= 4:
        return float(np.mean(v))
    tail = v[-min(5, v.size):]
    tail_med = np.median(tail)
    flat_mask = np.abs(v - tail_med) / max(abs(tail_med), 1e-6) < 0.05
    if flat_mask.sum() >= 3:
        return float(np.mean(v[flat_mask][-min(5, flat_mask.sum()):]))
    return float(np.mean(tail))



def observed_vflat_kms(galaxy: SPARCGalaxy) -> float:
    meta_vf = galaxy.metadata.get("vflat_kms")
    if meta_vf is not None and pd.notna(meta_vf):
        return float(meta_vf)
    return estimate_vflat_kms(galaxy.radius_kpc, galaxy.v_obs_kms)



def acceleration_mps2_from_vr(v_kms: np.ndarray, r_kpc: np.ndarray) -> np.ndarray:
    with np.errstate(divide="ignore", invalid="ignore"):
        return (v_kms**2 / r_kpc) * ACCEL_KMS2_PER_KPC_TO_MPS2


# -----------------------------------------------------------------------------
# Branch models
# -----------------------------------------------------------------------------


class BranchModel(abc.ABC):
    name: str

    @abc.abstractmethod
    def sparc_vcirc_kms(self, galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance) -> np.ndarray:
        raise NotImplementedError

    @abc.abstractmethod
    def cdg2_sigma_int_kms(self, data: CDG2Data, univ: UniversalParams, nuisance: GalaxyNuisance) -> float:
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def n_free_params(self) -> int:
        raise NotImplementedError




def _kg_m3_to_msun_kpc3(rho_si: float) -> float:
    return rho_si * (KPC_M**3) / MSUN_KG


def method_a_delta_v2_kms2(radius_kpc: np.ndarray, univ: UniversalParams) -> np.ndarray:
    """Method A from the galactic draft.

    The isotropic vacuum density contributes
        g_vac(r) = (4 pi G / 3) rho_vac r,
    so
        Delta v^2(r) = g_vac(r) r = (4 pi G / 3) rho_vac r^2.
    """
    rho_vac_si = max(univ.vacuum_density_si(), 0.0)
    r_m = np.asarray(radius_kpc, dtype=float) * KPC_M
    delta_v2_m2s2 = (4.0 * np.pi / 3.0) * G_SI * rho_vac_si * r_m**2
    return delta_v2_m2s2 / 1.0e6


def u_local_suppression_factor(vbar2_kms2: np.ndarray, v_screen_kms: float) -> np.ndarray:
    """U_local suppression: rho_vac(r) = beta * U_local^2(r).

    In a deep baryonic potential well U_local < U_cosmo, suppressing the
    vacuum backreaction where it is unwanted (compact massive spirals).
    The suppression factor is

        f_local(r) = U_local^2(r) / U_cosmo^2
                   = 1 / (1 + v_bar^2(r) / v_screen^2)

    derived from IS-3 (local field anchoring): the vacuum scalar field is
    sourced by the cosmological background minus the local baryonic
    potential depth.  v_screen is the single new free parameter; for
    v_bar << v_screen the galaxy is in the LSB/diffuse regime and
    f_local -> 1 (no suppression); for v_bar >> v_screen (compact
    massive spirals) f_local -> (v_screen/v_bar)^2 << 1.

    Applied to Method A: delta_v2 -> delta_v2 * f_local (since delta_v2
    proportional to rho_vac).
    Applied to Method C: boost_amplitude -> boost_amplitude * f_local.
    """
    v_screen2 = max(float(v_screen_kms), 1.0) ** 2
    vb2 = np.clip(np.asarray(vbar2_kms2, dtype=float), 0.0, None)
    return 1.0 / (1.0 + vb2 / v_screen2)


def method_a_delta_v2_kms2_suppressed(
    radius_kpc: np.ndarray,
    univ: "UniversalParamsV7",
    vbar2_kms2: np.ndarray,
) -> np.ndarray:
    """Method A with U_local suppression applied (MC4 branch only)."""
    base = method_a_delta_v2_kms2(radius_kpc, univ)
    f = u_local_suppression_factor(vbar2_kms2, univ.v_screen_kms)
    return base * f


def _characteristic_disk_scale_kpc(galaxy: SPARCGalaxy) -> float:
    for key in ("r_disk_kpc", "Rdisk", "r_eff_kpc", "Reff"):
        val = galaxy.metadata.get(key)
        if val is not None and pd.notna(val) and float(val) > 0:
            return float(val)
    r = np.asarray(galaxy.radius_kpc, dtype=float)
    if r.size == 0:
        return 1.0
    return max(float(np.nanmedian(r) / 2.0), 0.5)


def _interp_linear(x: np.ndarray, y: np.ndarray, x0: float) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    valid = np.isfinite(x) & np.isfinite(y)
    if valid.sum() == 0:
        return np.nan
    x = x[valid]
    y = y[valid]
    order = np.argsort(x)
    x = x[order]
    y = y[order]
    if x.size == 1:
        return float(y[0])
    x0 = float(np.clip(x0, x[0], x[-1]))
    return float(np.interp(x0, x, y))


def _effective_radius_kpc(galaxy: SPARCGalaxy) -> float:
    for key in ("r_eff_kpc", "Reff"):
        val = galaxy.metadata.get(key)
        if val is not None and pd.notna(val) and float(val) > 0:
            return float(val)
    r = np.asarray(galaxy.radius_kpc, dtype=float)
    if r.size == 0:
        return 1.0
    return max(float(np.nanmedian(r) / 3.0), 0.5)


def method_b_profile_form_factor(radius_kpc: np.ndarray, galaxy: SPARCGalaxy, nuisance: GalaxyNuisance) -> np.ndarray:
    """Disk-aware Method B radial kernel, v2.

    Compared with v1, this version makes ``R_IR`` matter through both an inner
    activation scale and an outer memory taper. That avoids the previous failure
    mode where the fit simply drove ``R_IR`` to the lower bound to saturate the
    boost everywhere.
    """
    r = np.asarray(radius_kpc, dtype=float)
    rd = max(_characteristic_disk_scale_kpc(galaxy), 1.0e-6)
    x = r / rd

    vgas2 = np.clip(signed_square(galaxy.v_gas_kms), 0.0, None)
    vdisk2 = np.clip(nuisance.upsilon_disk * galaxy.v_disk_kms**2, 0.0, None)
    vbul2 = np.clip(nuisance.upsilon_bulge * galaxy.v_bulge_kms**2, 0.0, None)
    vbar2 = np.clip(vgas2 + vdisk2 + vbul2, 1.0e-12, None)

    disk_frac = vdisk2 / vbar2
    gas_frac = vgas2 / vbar2
    bulge_frac = vbul2 / vbar2

    inner_supp = 1.0 - np.exp(-(x / 0.85) ** 2)
    optical_shoulder = 0.65 + 0.65 * np.exp(-0.5 * ((x - 2.2) / 0.95) ** 2)
    gas_support = np.clip(0.85 + 0.45 * gas_frac, 0.75, 1.35)
    disk_weight = np.clip(0.55 + 0.70 * disk_frac - 0.25 * bulge_frac, 0.20, 1.45)
    mild_outer = 1.0 / (1.0 + (x / 7.5) ** 1.5) ** 0.20

    return inner_supp * optical_shoulder * gas_support * disk_weight * mild_outer


def method_b_boost_factor(radius_kpc: np.ndarray, univ: UniversalParams, galaxy: SPARCGalaxy, nuisance: GalaxyNuisance) -> np.ndarray:
    """Method B from the galactic draft with a disk-aware transfer kernel."""
    r = np.asarray(radius_kpc, dtype=float)
    rd = max(_characteristic_disk_scale_kpc(galaxy), 1.0e-6)
    r_ir = max(float(univ.r_ir_kpc), 1.0e-6)
    inner_activation = 1.0 - np.exp(-(r / r_ir) ** 0.85)
    outer_memory_taper = 1.0 / (1.0 + (r / (2.8 * r_ir + 1.5 * rd)) ** 1.45)
    profile = method_b_profile_form_factor(r, galaxy, nuisance)
    boost = LAMBDA_BARE_OVER_GAMMA_W * inner_activation * outer_memory_taper * profile
    return np.clip(boost, -0.95, None)


def _method_c_observable(galaxy: SPARCGalaxy, nuisance: GalaxyNuisance, mode: str, base_value: float) -> float:
    meta = galaxy.metadata
    if mode == "constant":
        return float(base_value)

    if mode == "sb_eff":
        sb = meta.get("sb_eff_lsun_pc2")
        if sb is not None and pd.notna(sb) and float(sb) > 0:
            return float(np.log10(float(sb)))

    if mode == "sb_disk0":
        sb0 = meta.get("sb_disk0_lsun_pc2")
        if sb0 is not None and pd.notna(sb0) and float(sb0) > 0:
            return float(np.log10(float(sb0)))

    if mode == "sigma_bar_eff":
        mbar = baryonic_mass_msun(galaxy, nuisance)
        reff = _effective_radius_kpc(galaxy)
        if np.isfinite(mbar) and mbar > 0 and np.isfinite(reff) and reff > 0:
            sigma = mbar / (2.0 * np.pi * (reff * 1.0e3) ** 2)
            if sigma > 0:
                return float(np.log10(sigma))

    if mode == "sigma_star_eff":
        mstar = stellar_mass_msun(galaxy, nuisance)
        reff = _effective_radius_kpc(galaxy)
        if np.isfinite(mstar) and mstar > 0 and np.isfinite(reff) and reff > 0:
            sigma = mstar / (2.0 * np.pi * (reff * 1.0e3) ** 2)
            if sigma > 0:
                return float(np.log10(sigma))

    if mode == "sigma_gas_eff":
        mgas = gas_mass_msun(galaxy)
        reff = _effective_radius_kpc(galaxy)
        if np.isfinite(mgas) and mgas > 0 and np.isfinite(reff) and reff > 0:
            sigma = mgas / (2.0 * np.pi * (reff * 1.0e3) ** 2)
            if sigma > 0:
                return float(np.log10(sigma))

    if mode in {"gbar_2rd", "gbar_22rd", "baryon_compactness", "disk_dominance_22rd"}:
        rd = _characteristic_disk_scale_kpc(galaxy)
        target = (2.2 if mode in {"gbar_22rd", "baryon_compactness", "disk_dominance_22rd"} else 2.0) * rd
        vbar = baryonic_vcirc_kms(galaxy, nuisance)
        gbar = acceleration_mps2_from_vr(vbar, galaxy.radius_kpc)
        val = _interp_linear(galaxy.radius_kpc, gbar, target)
        if mode in {"gbar_2rd", "gbar_22rd"} and np.isfinite(val) and val > 0:
            return float(np.log10(val))
        if mode == "baryon_compactness":
            mbar = baryonic_mass_msun(galaxy, nuisance)
            if np.isfinite(mbar) and mbar > 0 and np.isfinite(rd) and rd > 0:
                sigma_disk = mbar / (2.0 * np.pi * (rd * 1.0e3) ** 2)
                if sigma_disk > 0:
                    return float(np.log10(sigma_disk))
        if mode == "disk_dominance_22rd":
            vdisk2 = np.clip(nuisance.upsilon_disk * galaxy.v_disk_kms**2, 0.0, None)
            vbul2 = np.clip(nuisance.upsilon_bulge * galaxy.v_bulge_kms**2, 0.0, None)
            vgas2 = np.clip(signed_square(galaxy.v_gas_kms), 0.0, None)
            vbar2 = np.clip(vdisk2 + vbul2 + vgas2, 1.0e-12, None)
            frac = _interp_linear(galaxy.radius_kpc, vdisk2 / vbar2, target)
            if np.isfinite(frac):
                frac = float(np.clip(frac, 1.0e-4, 1.0 - 1.0e-4))
                return float(np.log10(frac / (1.0 - frac)))

    if mode == "gas_fraction":
        mgas = gas_mass_msun(galaxy)
        mbar = baryonic_mass_msun(galaxy, nuisance)
        if np.isfinite(mgas) and np.isfinite(mbar) and mgas > 0 and mbar > 0:
            return float(np.log10(mgas / mbar))

    if mode == "gas_to_stellar":
        mgas = gas_mass_msun(galaxy)
        mstar = stellar_mass_msun(galaxy, nuisance)
        if np.isfinite(mgas) and np.isfinite(mstar) and mgas > 0 and mstar > 0:
            return float(np.log10(mgas / mstar))

    if mode == "stellar_fraction":
        mstar = stellar_mass_msun(galaxy, nuisance)
        mbar = baryonic_mass_msun(galaxy, nuisance)
        if np.isfinite(mstar) and np.isfinite(mbar) and mstar > 0 and mbar > 0:
            return float(np.log10(mstar / mbar))

    return float(base_value)


def _mc_get_obs_stats(mode: str) -> Tuple[float, float]:
    stats = PIPELINE_CONFIG.get("mc_obs_stats", {}) or {}
    if mode in stats:
        loc, scale = stats[mode]
        scale = float(scale) if np.isfinite(scale) and float(scale) > 1.0e-6 else 1.0
        return float(loc), scale
    return 0.0, 1.0


def _configure_mc_obs_stats(galaxies: Sequence[SPARCGalaxy], base_nuisance: GalaxyNuisance, modes: Sequence[str]) -> None:
    stats: Dict[str, Tuple[float, float]] = dict(PIPELINE_CONFIG.get("mc_obs_stats", {}) or {})
    for mode in modes:
        vals = []
        for galaxy in galaxies:
            nuisance = nuisance_for_galaxy(galaxy, base_nuisance)
            v = _method_c_observable(galaxy, nuisance, mode, nuisance.chi_env_obs)
            if np.isfinite(v):
                vals.append(float(v))
        if vals:
            arr = np.asarray(vals, dtype=float)
            med = float(np.nanmedian(arr))
            mad = float(np.nanmedian(np.abs(arr - med)))
            scale = 1.4826 * mad if mad > 1.0e-6 else float(np.nanstd(arr))
            if not np.isfinite(scale) or scale <= 1.0e-6:
                scale = 1.0
            stats[mode] = (med, scale)
    PIPELINE_CONFIG["mc_obs_stats"] = stats


def method_c_boost_factor(galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance) -> np.ndarray:
    """One-factor Method C implementation with pluggable gate observables."""
    theta = tuple(univ.theta_c) if univ.theta_c is not None else tuple()
    log10_chi_acc = theta[0] if len(theta) > 0 else 0.0
    center = theta[1] if len(theta) > 1 else 0.0
    log10_sharp = theta[2] if len(theta) > 2 else -0.3
    sharp = max(10.0 ** log10_sharp, 1.0e-3)
    chi_acc = 10.0 ** log10_chi_acc
    gate_mode = str(PIPELINE_CONFIG.get("mc_gate_mode", "sb_eff"))
    gate_obs = _method_c_observable(galaxy, nuisance, gate_mode, nuisance.chi_env_obs)
    activation = 1.0 / (1.0 + np.exp(-(gate_obs - center) / sharp))
    boost = chi_acc ** (1.0 - RNG_MEMORY_INDEX_N) * activation - 1.0
    return np.full_like(galaxy.radius_kpc, boost, dtype=float)


def method_c_twofactor_boost_factor(galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance) -> np.ndarray:
    """Two-factor Method C: composition gate times bounded morphology correction."""
    theta = tuple(univ.theta_c) if univ.theta_c is not None else tuple()
    log10_chi_acc = theta[0] if len(theta) > 0 else 0.0
    comp_center = theta[1] if len(theta) > 1 else 0.0
    log10_comp_sharp = theta[2] if len(theta) > 2 else -0.3
    morph_amp = theta[3] if len(theta) > 3 else 0.0
    comp_sharp = max(10.0 ** log10_comp_sharp, 1.0e-3)
    chi_acc = 10.0 ** log10_chi_acc

    comp_mode = str(PIPELINE_CONFIG.get("mc_comp_mode", PIPELINE_CONFIG.get("mc_gate_mode", "gas_to_stellar")))
    morph_mode = str(PIPELINE_CONFIG.get("mc_morph_mode", "baryon_compactness"))

    comp_obs = _method_c_observable(galaxy, nuisance, comp_mode, nuisance.chi_env_obs)
    comp_activation = 1.0 / (1.0 + np.exp(-(comp_obs - comp_center) / comp_sharp))

    morph_obs = _method_c_observable(galaxy, nuisance, morph_mode, nuisance.chi_env_obs)
    morph_loc, morph_scale = _mc_get_obs_stats(morph_mode)
    morph_z = (morph_obs - morph_loc) / max(morph_scale, 1.0e-6)
    morph_corr = float(np.exp(np.clip(morph_amp * np.tanh(morph_z), -3.0, 3.0)))

    boost = chi_acc ** (1.0 - RNG_MEMORY_INDEX_N) * comp_activation * morph_corr - 1.0
    return np.full_like(galaxy.radius_kpc, boost, dtype=float)


def method_c_sizeaware_boost_factor(galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance) -> np.ndarray:
    """Size-aware Method C: composition sets the outer amplitude while compactness moves the radial turn-on scale."""
    theta = tuple(univ.theta_c) if univ.theta_c is not None else tuple()
    log10_chi_acc = theta[0] if len(theta) > 0 else 0.0
    comp_center = theta[1] if len(theta) > 1 else 0.0
    log10_comp_sharp = theta[2] if len(theta) > 2 else -0.3
    morph_scale_amp = theta[3] if len(theta) > 3 else 0.0
    comp_sharp = max(10.0 ** log10_comp_sharp, 1.0e-3)
    chi_acc = 10.0 ** log10_chi_acc

    comp_mode = str(PIPELINE_CONFIG.get("mc_comp_mode", PIPELINE_CONFIG.get("mc_gate_mode", "gas_to_stellar")))
    morph_mode = str(PIPELINE_CONFIG.get("mc_morph_mode", "baryon_compactness"))

    comp_obs = _method_c_observable(galaxy, nuisance, comp_mode, nuisance.chi_env_obs)
    comp_activation = 1.0 / (1.0 + np.exp(-(comp_obs - comp_center) / comp_sharp))
    amp_outer = max(chi_acc ** (1.0 - RNG_MEMORY_INDEX_N) * comp_activation - 1.0, 0.0)

    morph_obs = _method_c_observable(galaxy, nuisance, morph_mode, nuisance.chi_env_obs)
    morph_loc, morph_scale = _mc_get_obs_stats(morph_mode)
    morph_z = (morph_obs - morph_loc) / max(morph_scale, 1.0e-6)
    morph_t = float(np.tanh(morph_z))

    r_resp = float(univ.r_ir_kpc) * float(np.exp(np.clip(-morph_scale_amp * morph_t, -2.5, 2.5)))
    rd_kpc = float(galaxy.metadata.get("Rdisk", galaxy.metadata.get("R_d_kpc", np.nan)))
    if not np.isfinite(rd_kpc) or rd_kpc <= 0.0:
        rd_kpc = float(np.nanmedian(galaxy.radius_kpc)) if galaxy.radius_kpc.size else 1.5
    r_floor = max(0.15 * rd_kpc, 0.25)
    r_resp_eff = float(np.clip(max(r_resp, r_floor), 0.1, 150.0))

    radial_response = 1.0 - np.exp(-np.clip(galaxy.radius_kpc, 0.0, None) / r_resp_eff)
    boost = amp_outer * radial_response
    return np.asarray(boost, dtype=float)


def method_c_uloc_suppressed_boost_factor(
    galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance
) -> np.ndarray:
    """Method C + U_local suppression (MC4 branch).

    Identical to MC3 (size-aware) except the boost amplitude at each
    radius is multiplied by the local suppression factor

        f_local(r) = 1 / (1 + v_bar^2(r) / v_screen^2)

    This implements U_local(r) = U_cosmo / sqrt(1 + v_bar^2/v_screen^2),
    so rho_vac(r) = beta * U_local^2(r) = beta * U_cosmo^2 * f_local(r).

    For LSBs (v_bar << v_screen): f_local -> 1 — no change from MC3.
    For compact massive spirals (v_bar >> v_screen): f_local -> 0 — boost
    amplitude is suppressed where baryonic potential is deep, directly
    addressing the amplitude-fence binding diagnostic from the hierarchical
    beta null result.
    """
    # Base boost from MC3 shape
    boost_shape = method_c_sizeaware_boost_factor(galaxy, univ, nuisance)
    # U_local suppression: use baryonic v^2 per point
    vbar2 = baryonic_v2_kms2(galaxy, nuisance)
    f_local = u_local_suppression_factor(vbar2, univ.v_screen_kms)
    return boost_shape * f_local


def enclosed_stellar_mass_msun(total_stellar_mass_msun: float, r_eval_kpc: float) -> float:
    _ = r_eval_kpc
    return total_stellar_mass_msun


def method_a_enclosed_mass_msun(r_eff_kpc: float, univ: UniversalParams) -> float:
    rho_vac_si = max(univ.vacuum_density_si(), 0.0)
    rho_vac_msun_kpc3 = _kg_m3_to_msun_kpc3(rho_vac_si)
    volume_kpc3 = (4.0 * np.pi / 3.0) * max(r_eff_kpc, 0.0) ** 3
    return rho_vac_msun_kpc3 * volume_kpc3


class NewtonianBranch(BranchModel):
    name = "M0"

    @property
    def n_free_params(self) -> int:
        return 0

    def sparc_vcirc_kms(self, galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance) -> np.ndarray:
        _ = univ
        return baryonic_vcirc_kms(galaxy, nuisance)

    def cdg2_sigma_int_kms(self, data: CDG2Data, univ: UniversalParams, nuisance: GalaxyNuisance) -> float:
        _ = univ
        m_eff = enclosed_stellar_mass_msun(data.stellar_mass_msun, nuisance.r_eff_kpc)
        return math.sqrt(max(nuisance.xi, 0.0) * G_KPC_KMS2_PER_MSUN * m_eff / max(nuisance.r_eff_kpc, 1e-6))


class MethodABranch(NewtonianBranch):
    name = "MA"

    @property
    def n_free_params(self) -> int:
        return 1

    def sparc_vcirc_kms(self, galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance) -> np.ndarray:
        vbar2 = baryonic_v2_kms2(galaxy, nuisance)
        return np.sqrt(np.clip(vbar2 + method_a_delta_v2_kms2(galaxy.radius_kpc, univ), 0.0, None))

    def cdg2_sigma_int_kms(self, data: CDG2Data, univ: UniversalParams, nuisance: GalaxyNuisance) -> float:
        m_eff = enclosed_stellar_mass_msun(data.stellar_mass_msun, nuisance.r_eff_kpc) + method_a_enclosed_mass_msun(
            nuisance.r_eff_kpc, univ
        )
        return math.sqrt(max(nuisance.xi, 0.0) * G_KPC_KMS2_PER_MSUN * m_eff / max(nuisance.r_eff_kpc, 1e-6))


class MethodBBranch(NewtonianBranch):
    name = "MB"

    @property
    def n_free_params(self) -> int:
        return 1

    def sparc_vcirc_kms(self, galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance) -> np.ndarray:
        vbar2 = baryonic_v2_kms2(galaxy, nuisance)
        boost = method_b_boost_factor(galaxy.radius_kpc, univ, galaxy, nuisance)
        return np.sqrt(np.clip(vbar2 * (1.0 + boost), 0.0, None))


class MethodABCombinedBranch(NewtonianBranch):
    name = "MAB"

    @property
    def n_free_params(self) -> int:
        return 2

    def sparc_vcirc_kms(self, galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance) -> np.ndarray:
        vbar2 = baryonic_v2_kms2(galaxy, nuisance)
        boost = method_b_boost_factor(galaxy.radius_kpc, univ, galaxy, nuisance)
        delta_a = method_a_delta_v2_kms2(galaxy.radius_kpc, univ)
        return np.sqrt(np.clip(vbar2 * (1.0 + boost) + delta_a, 0.0, None))

    def cdg2_sigma_int_kms(self, data: CDG2Data, univ: UniversalParams, nuisance: GalaxyNuisance) -> float:
        base = MethodABranch().cdg2_sigma_int_kms(data, univ, nuisance)
        proxy_galaxy = SPARCGalaxy(
            name=data.name,
            radius_kpc=np.asarray([nuisance.r_eff_kpc], dtype=float),
            v_obs_kms=np.zeros(1),
            v_err_kms=np.ones(1),
            v_gas_kms=np.zeros(1),
            v_disk_kms=np.zeros(1),
            v_bulge_kms=np.zeros(1),
            sb_disk_lsun_pc2=np.zeros(1),
            sb_bulge_lsun_pc2=np.zeros(1),
            metadata={"r_eff_kpc": nuisance.r_eff_kpc},
        )
        boost = method_b_boost_factor(np.asarray([nuisance.r_eff_kpc], dtype=float), univ, proxy_galaxy)[0]
        return base * math.sqrt(max(1.0 + boost, 1.0e-12))


class MethodCBranch(MethodABCombinedBranch):
    name = "MC"

    @property
    def n_free_params(self) -> int:
        return 5

    def sparc_vcirc_kms(self, galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance) -> np.ndarray:
        vab2 = super().sparc_vcirc_kms(galaxy, univ, nuisance) ** 2
        vbar2 = baryonic_v2_kms2(galaxy, nuisance)
        boost_c = method_c_boost_factor(galaxy, univ, nuisance)
        return np.sqrt(np.clip(vab2 + boost_c * np.maximum(vbar2, 0.0), 0.0, None))


class MethodCTwoFactorBranch(MethodABCombinedBranch):
    name = "MC2"

    @property
    def n_free_params(self) -> int:
        return 6

    def sparc_vcirc_kms(self, galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance) -> np.ndarray:
        vab2 = super().sparc_vcirc_kms(galaxy, univ, nuisance) ** 2
        vbar2 = baryonic_v2_kms2(galaxy, nuisance)
        boost_c = method_c_twofactor_boost_factor(galaxy, univ, nuisance)
        return np.sqrt(np.clip(vab2 + boost_c * np.maximum(vbar2, 0.0), 0.0, None))


class MethodCSizeAwareBranch(MethodABCombinedBranch):
    name = "MC3"

    @property
    def n_free_params(self) -> int:
        return 6

    def sparc_vcirc_kms(self, galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance) -> np.ndarray:
        vab2 = super().sparc_vcirc_kms(galaxy, univ, nuisance) ** 2
        vbar2 = baryonic_v2_kms2(galaxy, nuisance)
        boost_c = method_c_sizeaware_boost_factor(galaxy, univ, nuisance)
        return np.sqrt(np.clip(vab2 + boost_c * np.maximum(vbar2, 0.0), 0.0, None))


class MethodCUlocBranch(MethodABCombinedBranch):
    """MC4: MC3 (size-aware radial correction) + U_local suppression.

    Adds one free parameter: log10(v_screen_kms) in [1.0, 3.0].
    v_screen is the baryonic velocity scale at which the vacuum
    backreaction is suppressed by half: f_local = 0.5 at v_bar = v_screen.

    This implements the IS-3 U_local anchoring: in deep potential wells
    (compact spirals) the local vacuum field is suppressed relative to
    the cosmological background, reducing Method C amplitude without
    affecting LSBs or dwarf galaxies.
    """

    name = "MC4"

    @property
    def n_free_params(self) -> int:
        return 7  # MC3 params (6) + log10_v_screen (1)

    def sparc_vcirc_kms(self, galaxy: SPARCGalaxy, univ: UniversalParams, nuisance: GalaxyNuisance) -> np.ndarray:
        vbar2 = baryonic_v2_kms2(galaxy, nuisance)
        # Method A with U_local suppression (numerically negligible but theoretically correct)
        r = galaxy.radius_kpc
        delta_a = method_a_delta_v2_kms2(r, univ)
        f_local = u_local_suppression_factor(vbar2, univ.v_screen_kms)
        delta_a_suppressed = delta_a * f_local
        # Method B boost (unchanged — B is memory-IR, not vacuum backreaction)
        boost_b = method_b_boost_factor(r, univ, galaxy, nuisance)
        vab2 = np.clip(vbar2 * (1.0 + boost_b) + delta_a_suppressed, 0.0, None)
        # Method C with U_local suppression applied to boost amplitude
        boost_c = method_c_uloc_suppressed_boost_factor(galaxy, univ, nuisance)
        return np.sqrt(np.clip(vab2 + boost_c * np.maximum(vbar2, 0.0), 0.0, None))

    def cdg2_sigma_int_kms(self, data: "CDG2Data", univ: UniversalParams, nuisance: "GalaxyNuisance") -> float:
        # CDG-2 is a diffuse LSB system: v_bar << v_screen, f_local ~ 1, reduce to MC3
        return MethodCSizeAwareBranch().cdg2_sigma_int_kms(data, univ, nuisance)


BRANCHES: Dict[str, BranchModel] = {
    b.name: b
    for b in (
        NewtonianBranch(),
        MethodABranch(),
        MethodBBranch(),
        MethodABCombinedBranch(),
        MethodCBranch(),
        MethodCTwoFactorBranch(),
        MethodCSizeAwareBranch(),
        MethodCUlocBranch(),
    )
}


# -----------------------------------------------------------------------------
# Fitting utilities
# -----------------------------------------------------------------------------




def _derive_env_proxy_from_metadata(galaxy: SPARCGalaxy, base: GalaxyNuisance) -> float:
    meta = galaxy.metadata
    if "chi_env_obs" in meta and pd.notna(meta.get("chi_env_obs")):
        return float(meta["chi_env_obs"])
    return _method_c_observable(galaxy, base, str(PIPELINE_CONFIG.get("mc_gate_mode", "sb_eff")), base.chi_env_obs)


def nuisance_for_galaxy(galaxy: SPARCGalaxy, base: GalaxyNuisance) -> GalaxyNuisance:
    meta = galaxy.metadata
    seeded = GalaxyNuisance(
        upsilon_disk=float(meta.get("upsilon_disk", base.upsilon_disk)),
        upsilon_bulge=float(meta.get("upsilon_bulge", base.upsilon_bulge)),
        distance_mpc=float(meta.get("distance_mpc", base.distance_mpc)),
        inclination_deg=float(meta.get("inclination_deg", base.inclination_deg)),
        r_eff_kpc=float(meta.get("r_eff_kpc", base.r_eff_kpc)),
        xi=float(meta.get("xi", base.xi)),
        chi_env_obs=float(base.chi_env_obs),
        sigma_int_scatter=float(meta.get("sigma_int_scatter", base.sigma_int_scatter)),
    )
    return GalaxyNuisance(
        upsilon_disk=seeded.upsilon_disk,
        upsilon_bulge=seeded.upsilon_bulge,
        distance_mpc=seeded.distance_mpc,
        inclination_deg=seeded.inclination_deg,
        r_eff_kpc=seeded.r_eff_kpc,
        xi=seeded.xi,
        chi_env_obs=_derive_env_proxy_from_metadata(galaxy, seeded),
        sigma_int_scatter=seeded.sigma_int_scatter,
    )


def _vector_to_params(branch: BranchModel, x: np.ndarray) -> UniversalParams:
    x = np.asarray(x, dtype=float)
    if branch.name == "M0":
        return UniversalParams(beta=0.0, r_ir_kpc=5.0, theta_c=(0.0, 0.0, -0.3))
    if branch.name == "MA":
        return UniversalParams(beta=10 ** x[0], r_ir_kpc=5.0, theta_c=(0.0, 0.0, -0.3))
    if branch.name == "MB":
        return UniversalParams(beta=0.0, r_ir_kpc=10 ** x[0], theta_c=(0.0, 0.0, -0.3))
    if branch.name == "MAB":
        return UniversalParams(beta=10 ** x[0], r_ir_kpc=10 ** x[1], theta_c=(0.0, 0.0, -0.3))
    if branch.name == "MC":
        return UniversalParams(beta=10 ** x[0], r_ir_kpc=10 ** x[1], theta_c=(x[2], x[3], x[4]))
    if branch.name == "MC2":
        return UniversalParams(beta=10 ** x[0], r_ir_kpc=10 ** x[1], theta_c=(x[2], x[3], x[4], x[5]))
    if branch.name == "MC3":
        return UniversalParams(beta=10 ** x[0], r_ir_kpc=10 ** x[1], theta_c=(x[2], x[3], x[4], x[5]))
    if branch.name == "MC4":
        # x[6] = log10(v_screen_kms), so v_screen = 10^x[6]
        return UniversalParams(
            beta=10 ** x[0], r_ir_kpc=10 ** x[1],
            theta_c=(x[2], x[3], x[4], x[5]),
            v_screen_kms=10 ** x[6],
        )
    raise KeyError(branch.name)


def _initial_guess(branch: BranchModel) -> np.ndarray:
    if branch.name == "M0":
        return np.zeros(0)
    if branch.name == "MA":
        return np.array([0.0])
    if branch.name == "MB":
        return np.array([1.0])
    if branch.name == "MAB":
        return np.array([0.0, 1.0])
    if branch.name == "MC":
        return np.array([0.0, 1.0, 0.0, 0.0, -0.3])
    if branch.name == "MC2":
        return np.array([0.0, 1.0, 0.0, 0.0, -0.3, 0.0])
    if branch.name == "MC3":
        return np.array([0.0, 1.0, 0.0, 0.0, -0.3, 0.0])
    if branch.name == "MC4":
        # Extra param: log10(v_screen_kms), start at 2.0 = 100 km/s
        return np.array([0.0, 1.0, 0.0, 0.0, -0.3, 0.0, 2.0])
    raise KeyError(branch.name)


def _bounds(branch: BranchModel) -> List[Tuple[float, float]]:
    beta_hi = float(np.log10(max(UniversalParams().rho_lambda_max_si / UniversalParams().u0_sq_over_c2_si, 1.0)))
    if branch.name == "M0":
        return []
    if branch.name == "MA":
        return [(-8.0, beta_hi)]
    if branch.name == "MB":
        return [(-2.0, 2.0)]
    if branch.name == "MAB":
        return [(-8.0, beta_hi), (-2.0, 2.0)]
    if branch.name == "MC":
        return [(-8.0, beta_hi), (-2.0, 2.0), (-2.0, 2.0), (-2.5, 2.5), (-2.0, 1.0)]
    if branch.name == "MC2":
        return [(-8.0, beta_hi), (-2.0, 2.0), (-2.0, 2.0), (-2.5, 2.5), (-2.0, 1.0), (-2.0, 2.0)]
    if branch.name == "MC3":
        return [(-8.0, beta_hi), (-2.0, 2.0), (-2.0, 2.0), (-2.5, 2.5), (-2.0, 1.0), (-2.0, 2.0)]
    if branch.name == "MC4":
        # Same as MC3 plus log10(v_screen_kms) in [1.0, 3.0] -> v_screen in [10, 1000] km/s
        return [(-8.0, beta_hi), (-2.0, 2.0), (-2.0, 2.0), (-2.5, 2.5), (-2.0, 1.0), (-2.0, 2.0), (1.0, 3.0)]
    raise KeyError(branch.name)


def branch_objective(x: np.ndarray, branch: BranchModel, galaxies: Sequence[SPARCGalaxy], base_nuisance: GalaxyNuisance) -> float:
    params = _vector_to_params(branch, x)
    try:
        params.check_cosmology_fence()
    except ValueError:
        return 1e30
    total = 0.0
    for galaxy in galaxies:
        nuisance = nuisance_for_galaxy(galaxy, base_nuisance)
        model = branch.sparc_vcirc_kms(galaxy, params, nuisance)
        sigma = np.sqrt(galaxy.v_err_kms**2 + nuisance.sigma_int_scatter**2)
        valid = np.isfinite(model) & np.isfinite(galaxy.v_obs_kms) & np.isfinite(sigma) & (sigma > 0)
        if not np.any(valid):
            continue
        resid = (model[valid] - galaxy.v_obs_kms[valid]) / sigma[valid]
        total += float(np.sum(resid**2 + np.log(sigma[valid] ** 2)))
    return total



def fit_branch(galaxies: Sequence[SPARCGalaxy], branch: BranchModel, base_nuisance: GalaxyNuisance) -> FitResult:
    x0 = _initial_guess(branch)
    bnds = _bounds(branch)
    if x0.size == 0:
        params = _vector_to_params(branch, x0)
        obj = branch_objective(x0, branch, galaxies, base_nuisance)
        n_points = int(sum(g.radius_kpc.size for g in galaxies))
        dof = max(n_points - branch.n_free_params, 1)
        return FitResult(
            branch=branch.name,
            params=params,
            objective=obj,
            success=True,
            message="closed-form/no-fit branch",
            n_galaxies=len(galaxies),
            n_points=n_points,
            reduced_chi2=obj / dof,
            aic=obj + 2 * branch.n_free_params,
            bic=obj + branch.n_free_params * np.log(max(n_points, 1)),
        )

    rng = np.random.default_rng(12345)
    starts = [x0]
    lows = np.asarray([b[0] for b in bnds], dtype=float)
    highs = np.asarray([b[1] for b in bnds], dtype=float)
    starts.append(0.5 * (lows + highs))
    for _ in range(3 if branch.n_free_params >= 5 else 6):
        starts.append(rng.uniform(lows, highs))

    best = None
    for start in starts:
        res = minimize(
            fun=lambda x: branch_objective(x, branch, galaxies, base_nuisance),
            x0=np.asarray(start, dtype=float),
            bounds=bnds,
            method="L-BFGS-B",
        )
        if best is None or float(res.fun) < float(best.fun):
            best = res

    assert best is not None
    params = _vector_to_params(branch, best.x)
    n_points = int(sum(g.radius_kpc.size for g in galaxies))
    dof = max(n_points - branch.n_free_params, 1)
    return FitResult(
        branch=branch.name,
        params=params,
        objective=float(best.fun),
        success=bool(best.success),
        message=str(best.message),
        n_galaxies=len(galaxies),
        n_points=n_points,
        reduced_chi2=float(best.fun) / dof,
        aic=float(best.fun) + 2 * branch.n_free_params,
        bic=float(best.fun) + branch.n_free_params * np.log(max(n_points, 1)),
    )


# -----------------------------------------------------------------------------
# Diagnostics and summaries
# -----------------------------------------------------------------------------



def per_galaxy_summary(galaxies: Sequence[SPARCGalaxy], fit: FitResult, base_nuisance: GalaxyNuisance) -> pd.DataFrame:
    branch = BRANCHES[fit.branch]
    rows: List[Dict[str, Any]] = []
    for galaxy in galaxies:
        nuisance = nuisance_for_galaxy(galaxy, base_nuisance)
        model = branch.sparc_vcirc_kms(galaxy, fit.params, nuisance)
        sigma = np.sqrt(galaxy.v_err_kms**2 + nuisance.sigma_int_scatter**2)
        valid = np.isfinite(model) & np.isfinite(galaxy.v_obs_kms) & np.isfinite(sigma) & (sigma > 0)
        if valid.sum() == 0:
            continue
        chi2 = float(np.sum(((model[valid] - galaxy.v_obs_kms[valid]) / sigma[valid]) ** 2))
        rms = float(np.sqrt(np.mean((model[valid] - galaxy.v_obs_kms[valid]) ** 2)))
        vf_obs = observed_vflat_kms(galaxy)
        vf_model = estimate_vflat_kms(galaxy.radius_kpc[valid], model[valid])
        mbar = baryonic_mass_msun(galaxy, nuisance)
        rows.append(
            {
                "name": galaxy.name,
                "n_points": int(valid.sum()),
                "chi2": chi2,
                "reduced_chi2": chi2 / max(int(valid.sum()) - 1, 1),
                "rms_resid_kms": rms,
                "vf_obs_kms": vf_obs,
                "vf_model_kms": vf_model,
                "mbar_msun": mbar,
                "distance_mpc": galaxy.distance_mpc,
                "Q": galaxy.q_flag,
                "chi_env_obs": nuisance.chi_env_obs,
            }
        )
    return pd.DataFrame(rows).sort_values("reduced_chi2", ascending=True)



def collect_radius_residuals(galaxies: Sequence[SPARCGalaxy], fit: FitResult, base_nuisance: GalaxyNuisance) -> pd.DataFrame:
    branch = BRANCHES[fit.branch]
    rows: List[Dict[str, Any]] = []
    for galaxy in galaxies:
        nuisance = nuisance_for_galaxy(galaxy, base_nuisance)
        model = branch.sparc_vcirc_kms(galaxy, fit.params, nuisance)
        rmax = float(np.nanmax(galaxy.radius_kpc))
        for r, vo, vm, ve in zip(galaxy.radius_kpc, galaxy.v_obs_kms, model, galaxy.v_err_kms):
            if not np.isfinite(r + vo + vm + ve):
                continue
            rows.append(
                {
                    "name": galaxy.name,
                    "radius_kpc": r,
                    "radius_over_rmax": r / max(rmax, 1e-6),
                    "v_obs_kms": vo,
                    "v_model_kms": vm,
                    "resid_kms": vm - vo,
                    "frac_resid": (vm - vo) / max(abs(vo), 1e-6),
                    "v_err_kms": ve,
                }
            )
    return pd.DataFrame(rows)



def btfr_summary(galaxies: Sequence[SPARCGalaxy], fit: FitResult, base_nuisance: GalaxyNuisance) -> Tuple[pd.DataFrame, Dict[str, float]]:
    branch = BRANCHES[fit.branch]
    rows: List[Dict[str, float]] = []
    for galaxy in galaxies:
        nuisance = nuisance_for_galaxy(galaxy, base_nuisance)
        mbar = baryonic_mass_msun(galaxy, nuisance)
        if not np.isfinite(mbar) or mbar <= 0:
            continue
        vf_obs = observed_vflat_kms(galaxy)
        vf_model = estimate_vflat_kms(galaxy.radius_kpc, branch.sparc_vcirc_kms(galaxy, fit.params, nuisance))
        if not np.isfinite(vf_obs) or not np.isfinite(vf_model):
            continue
        rows.append({
            "name": galaxy.name,
            "log10_mbar": np.log10(mbar),
            "log10_vf_obs": np.log10(max(vf_obs, 1e-6)),
            "log10_vf_model": np.log10(max(vf_model, 1e-6)),
        })
    df = pd.DataFrame(rows)
    metrics: Dict[str, float] = {}
    if len(df) >= 3:
        obs_coef = np.polyfit(df["log10_vf_obs"], df["log10_mbar"], 1)
        mod_coef = np.polyfit(df["log10_vf_model"], df["log10_mbar"], 1)
        obs_pred = np.polyval(obs_coef, df["log10_vf_obs"])
        mod_pred = np.polyval(mod_coef, df["log10_vf_model"])
        metrics = {
            "obs_slope": float(obs_coef[0]),
            "obs_intercept": float(obs_coef[1]),
            "obs_scatter_dex": float(np.std(df["log10_mbar"] - obs_pred, ddof=1)),
            "model_slope": float(mod_coef[0]),
            "model_intercept": float(mod_coef[1]),
            "model_scatter_dex": float(np.std(df["log10_mbar"] - mod_pred, ddof=1)),
        }
    return df, metrics



def rar_summary(galaxies: Sequence[SPARCGalaxy], fit: FitResult, base_nuisance: GalaxyNuisance) -> Tuple[pd.DataFrame, Dict[str, float]]:
    branch = BRANCHES[fit.branch]
    rows: List[Dict[str, float]] = []
    for galaxy in galaxies:
        nuisance = nuisance_for_galaxy(galaxy, base_nuisance)
        vbar = baryonic_vcirc_kms(galaxy, nuisance)
        vmodel = branch.sparc_vcirc_kms(galaxy, fit.params, nuisance)
        gbar = acceleration_mps2_from_vr(vbar, galaxy.radius_kpc)
        gobs = acceleration_mps2_from_vr(galaxy.v_obs_kms, galaxy.radius_kpc)
        gmodel = acceleration_mps2_from_vr(vmodel, galaxy.radius_kpc)
        for r, gb, go, gm in zip(galaxy.radius_kpc, gbar, gobs, gmodel):
            if min(gb, go, gm) <= 0 or not np.isfinite(gb + go + gm):
                continue
            rows.append(
                {
                    "name": galaxy.name,
                    "radius_kpc": r,
                    "log10_gbar": np.log10(gb),
                    "log10_gobs": np.log10(go),
                    "log10_gmodel": np.log10(gm),
                    "delta_logg_model_minus_obs": np.log10(gm) - np.log10(go),
                }
            )
    df = pd.DataFrame(rows)
    metrics: Dict[str, float] = {}
    if len(df) >= 3:
        metrics = {
            "rms_delta_logg": float(np.sqrt(np.mean(df["delta_logg_model_minus_obs"] ** 2))),
            "median_delta_logg": float(np.median(df["delta_logg_model_minus_obs"])),
        }
    return df, metrics


# -----------------------------------------------------------------------------
# Plotting
# -----------------------------------------------------------------------------



def save_residual_plot(resid_df: pd.DataFrame, outpath: Path, title: str) -> None:
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(resid_df["radius_over_rmax"], resid_df["frac_resid"], s=8, alpha=0.4)
    ax.axhline(0.0, linewidth=1)
    ax.set_xlabel(r"$r / r_{\max}$")
    ax.set_ylabel(r"$(V_{\rm model} - V_{\rm obs}) / V_{\rm obs}$")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(outpath, dpi=180)
    plt.close(fig)



def save_btfr_plot(df: pd.DataFrame, outpath: Path, title: str) -> None:
    fig, ax = plt.subplots(figsize=(6.5, 5.5))
    ax.scatter(df["log10_vf_obs"], df["log10_mbar"], s=10, alpha=0.55, label="observed")
    ax.scatter(df["log10_vf_model"], df["log10_mbar"], s=10, alpha=0.55, label="model")
    ax.set_xlabel(r"$\log_{10} V_f\ [{\rm km\ s^{-1}}]$")
    ax.set_ylabel(r"$\log_{10} M_{\rm bar}\ [M_\odot]$")
    ax.set_title(title)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(outpath, dpi=180)
    plt.close(fig)



def save_rar_plot(df: pd.DataFrame, outpath: Path, title: str) -> None:
    fig, ax = plt.subplots(figsize=(6.5, 5.5))
    ax.scatter(df["log10_gbar"], df["log10_gobs"], s=6, alpha=0.25, label="observed")
    ax.scatter(df["log10_gbar"], df["log10_gmodel"], s=6, alpha=0.25, label="model")
    ax.set_xlabel(r"$\log_{10} g_{\rm bar}\ [{\rm m\ s^{-2}}]$")
    ax.set_ylabel(r"$\log_{10} g\ [{\rm m\ s^{-2}}]$")
    ax.set_title(title)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(outpath, dpi=180)
    plt.close(fig)


# -----------------------------------------------------------------------------
# CDG-2 lightweight likelihood
# -----------------------------------------------------------------------------



def cdg2_loglike(data: CDG2Data, branch: BranchModel, params: UniversalParams, nuisance: GalaxyNuisance) -> float:
    sigma_int = branch.cdg2_sigma_int_kms(data, params, nuisance)
    var = sigma_int**2 + data.errors_kms**2
    vbar = float(np.mean(data.velocities_kms))
    return float(-0.5 * np.sum((data.velocities_kms - vbar) ** 2 / var + np.log(var)))


# -----------------------------------------------------------------------------
# Orchestration
# -----------------------------------------------------------------------------



def run_sparc_pipeline(
    rotmod_dir: Path,
    output_dir: Path,
    metadata_path: Optional[Path] = None,
    branch_names: Sequence[str] = ("M0", "MA", "MB", "MAB", "MC"),
    max_quality_flag: Optional[int] = 2,
    default_chi_env: float = 1.0,
    mc_gate_mode: str = "sb_eff",
    mc_comp_mode: str = "gas_to_stellar",
    mc_morph_mode: str = "baryon_compactness",
) -> Dict[str, FitResult]:
    output_dir.mkdir(parents=True, exist_ok=True)
    PIPELINE_CONFIG["mc_gate_mode"] = mc_gate_mode
    PIPELINE_CONFIG["mc_comp_mode"] = mc_comp_mode
    PIPELINE_CONFIG["mc_morph_mode"] = mc_morph_mode
    galaxies = load_sparc_sample(rotmod_dir=rotmod_dir, metadata_path=metadata_path)
    for g in galaxies:
        g.metadata.setdefault("chi_env_obs", default_chi_env)

    if max_quality_flag is not None:
        galaxies = [g for g in galaxies if g.q_flag is None or g.q_flag <= max_quality_flag]
    if not galaxies:
        raise ValueError("No SPARC galaxies remain after quality filtering")

    base_nuisance = GalaxyNuisance()
    _configure_mc_obs_stats(
        galaxies,
        base_nuisance,
        [
            str(mc_gate_mode),
            str(PIPELINE_CONFIG.get("mc_comp_mode", "gas_to_stellar")),
            str(PIPELINE_CONFIG.get("mc_morph_mode", "baryon_compactness")),
        ],
    )
    results: Dict[str, FitResult] = {}
    comparison_rows: List[Dict[str, Any]] = []

    for branch_name in branch_names:
        branch = BRANCHES[branch_name]
        fit = fit_branch(galaxies, branch, base_nuisance)
        results[branch_name] = fit
        summary_df = per_galaxy_summary(galaxies, fit, base_nuisance)
        resid_df = collect_radius_residuals(galaxies, fit, base_nuisance)
        btfr_df, btfr_metrics = btfr_summary(galaxies, fit, base_nuisance)
        rar_df, rar_metrics = rar_summary(galaxies, fit, base_nuisance)

        fit.diagnostics.update(btfr_metrics)
        fit.diagnostics.update(rar_metrics)

        summary_df.to_csv(output_dir / f"per_galaxy_summary_{branch_name}.csv", index=False)
        resid_df.to_csv(output_dir / f"residuals_{branch_name}.csv", index=False)
        btfr_df.to_csv(output_dir / f"btfr_points_{branch_name}.csv", index=False)
        rar_df.to_csv(output_dir / f"rar_points_{branch_name}.csv", index=False)
        (output_dir / f"fit_result_{branch_name}.json").write_text(
            json.dumps(
                {
                    **asdict(fit),
                    "params": asdict(fit.params),
                },
                indent=2,
                default=lambda o: o.tolist() if isinstance(o, np.ndarray) else o,
            ),
            encoding="utf-8",
        )

        if not resid_df.empty:
            save_residual_plot(resid_df, output_dir / f"residual_plot_{branch_name}.png", f"{branch_name} residuals")
        if not btfr_df.empty:
            save_btfr_plot(btfr_df, output_dir / f"btfr_{branch_name}.png", f"{branch_name} BTFR check")
        if not rar_df.empty:
            save_rar_plot(rar_df, output_dir / f"rar_{branch_name}.png", f"{branch_name} RAR diagnostic")

        comparison_rows.append(
            {
                "branch": branch_name,
                "objective": fit.objective,
                "reduced_chi2": fit.reduced_chi2,
                "aic": fit.aic,
                "bic": fit.bic,
                "beta": fit.params.beta,
                "r_ir_kpc": fit.params.r_ir_kpc,
                "theta_c0": fit.params.theta_c[0] if fit.params.theta_c else np.nan,
                "v_screen_kms": fit.params.v_screen_kms if branch_name == "MC4" else np.nan,
                "mc_gate_mode": str(PIPELINE_CONFIG.get("mc_gate_mode", "sb_eff")) if branch_name == "MC" else "",
                "mc_comp_mode": str(PIPELINE_CONFIG.get("mc_comp_mode", "gas_to_stellar")) if branch_name in {"MC2", "MC3", "MC4"} else "",
                "mc_morph_mode": str(PIPELINE_CONFIG.get("mc_morph_mode", "baryon_compactness")) if branch_name in {"MC2", "MC3", "MC4"} else "",
                "method_b_kernel": str(PIPELINE_CONFIG.get("method_b_kernel", "disk_aware_v2")) if branch_name in {"MB", "MAB", "MC", "MC2", "MC3", "MC4"} else "",
                **fit.diagnostics,
            }
        )

    comparison_df = pd.DataFrame(comparison_rows).sort_values("bic")
    comparison_df.to_csv(output_dir / "branch_comparison.csv", index=False)
    return results


def run_method_c_gate_benchmark(
    rotmod_dir: Path,
    output_dir: Path,
    metadata_path: Optional[Path] = None,
    gate_modes: Sequence[str] = METHOD_C_GATE_MODES,
    max_quality_flag: Optional[int] = 2,
    default_chi_env: float = 1.0,
) -> pd.DataFrame:
    output_dir.mkdir(parents=True, exist_ok=True)
    rows: List[Dict[str, Any]] = []
    for gate_mode in gate_modes:
        gate_dir = output_dir / f"mc_gate_{gate_mode}"
        results = run_sparc_pipeline(
            rotmod_dir=rotmod_dir,
            output_dir=gate_dir,
            metadata_path=metadata_path,
            branch_names=("MC",),
            max_quality_flag=max_quality_flag,
            default_chi_env=default_chi_env,
            mc_gate_mode=gate_mode,
        )
        fit = results["MC"]
        rows.append({
            "gate_mode": gate_mode,
            "objective": fit.objective,
            "reduced_chi2": fit.reduced_chi2,
            "aic": fit.aic,
            "bic": fit.bic,
            "beta": fit.params.beta,
            "r_ir_kpc": fit.params.r_ir_kpc,
            "theta_c0": fit.params.theta_c[0] if fit.params.theta_c else np.nan,
            "theta_c1": fit.params.theta_c[1] if len(fit.params.theta_c) > 1 else np.nan,
            "theta_c2": fit.params.theta_c[2] if len(fit.params.theta_c) > 2 else np.nan,
            "v_screen_kms": fit.params.v_screen_kms,
            **fit.diagnostics,
        })
    df = pd.DataFrame(rows).sort_values("bic")
    df.to_csv(output_dir / "method_c_gate_benchmark.csv", index=False)
    return df


# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------



def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="MSTG/SPARC galactic test pipeline (v6 size-aware Method C patch)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_sparc = sub.add_parser("fit-sparc", help="Fit SPARC rotation curves and emit diagnostics")
    p_sparc.add_argument("--rotmod-dir", type=Path, required=True, help="Directory containing official *_rotmod.dat files")
    p_sparc.add_argument("--metadata", type=Path, default=None, help="Optional SPARC_Lelli2016c.mrt or CSV/TSV/JSON metadata")
    p_sparc.add_argument("--output-dir", type=Path, required=True, help="Directory for CSV/JSON/PNG outputs")
    p_sparc.add_argument(
        "--branches",
        nargs="+",
        default=["M0", "MA", "MB", "MAB", "MC", "MC2", "MC3", "MC4"],
        choices=sorted(BRANCHES.keys()),
        help="Branches to fit",
    )
    p_sparc.add_argument("--max-quality-flag", type=int, default=2, help="Retain Q<=this threshold; use 99 to keep all")
    p_sparc.add_argument("--default-chi-env", type=float, default=1.0, help="Fallback environment proxy when metadata is absent")
    p_sparc.add_argument("--mc-gate-mode", type=str, default="sb_eff", choices=METHOD_C_GATE_MODES, help="One-factor MC observable used for the gate proxy")
    p_sparc.add_argument("--mc-comp-mode", type=str, default="gas_to_stellar", choices=METHOD_C_GATE_MODES, help="Two-factor MC2 composition observable")
    p_sparc.add_argument("--mc-morph-mode", type=str, default="baryon_compactness", choices=METHOD_C_GATE_MODES, help="Two-factor MC2 morphology observable")

    p_gate = sub.add_parser("benchmark-mc-gates", help="Benchmark multiple Method C gate observables")
    p_gate.add_argument("--rotmod-dir", type=Path, required=True, help="Directory containing official *_rotmod.dat files")
    p_gate.add_argument("--metadata", type=Path, default=None, help="Optional SPARC_Lelli2016c.mrt or CSV/TSV/JSON metadata")
    p_gate.add_argument("--output-dir", type=Path, required=True, help="Directory for CSV/JSON/PNG outputs")
    p_gate.add_argument("--gate-modes", nargs="+", default=list(METHOD_C_GATE_MODES), choices=METHOD_C_GATE_MODES, help="Gate observables to benchmark")
    p_gate.add_argument("--max-quality-flag", type=int, default=2, help="Retain Q<=this threshold; use 99 to keep all")
    p_gate.add_argument("--default-chi-env", type=float, default=1.0, help="Fallback environment proxy when metadata is absent")
    return parser



def main(argv: Optional[Sequence[str]] = None) -> None:
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    if args.cmd == "fit-sparc":
        max_q = None if args.max_quality_flag >= 99 else args.max_quality_flag
        run_sparc_pipeline(
            rotmod_dir=args.rotmod_dir,
            output_dir=args.output_dir,
            metadata_path=args.metadata,
            branch_names=args.branches,
            max_quality_flag=max_q,
            default_chi_env=args.default_chi_env,
            mc_gate_mode=args.mc_gate_mode,
            mc_comp_mode=args.mc_comp_mode,
            mc_morph_mode=args.mc_morph_mode,
        )
        return
    if args.cmd == "benchmark-mc-gates":
        max_q = None if args.max_quality_flag >= 99 else args.max_quality_flag
        run_method_c_gate_benchmark(
            rotmod_dir=args.rotmod_dir,
            output_dir=args.output_dir,
            metadata_path=args.metadata,
            gate_modes=args.gate_modes,
            max_quality_flag=max_q,
            default_chi_env=args.default_chi_env,
        )
        return
    raise KeyError(args.cmd)


if __name__ == "__main__":
    main()

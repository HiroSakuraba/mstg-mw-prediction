import sys,json,numpy as np
from pathlib import Path
S=Path(sys.argv[1]); sys.path.insert(0,str(S/'pipe')); import mstgv7 as m
G=4.30091e-6
fit=json.load(open(S/'out_v7/fit_result_MC4.json')); p=fit['params']
univ=m.UniversalParams(beta=p['beta'],r_ir_kpc=p['r_ir_kpc'],theta_c=tuple(p['theta_c']),v_screen_kms=p['v_screen_kms'])
m.PIPELINE_CONFIG.update(mc_comp_mode="gas_to_stellar",mc_morph_mode="baryon_compactness",
    mc_obs_stats={"gas_to_stellar":(0.011,0.688),"baryon_compactness":(2.303,0.565)})
def hern(R,M,a): return G*M*R/(R+a)**2
def mn(R,M,a,b): return G*M*R**2/(R**2+(a+b)**2)**1.5
MB,MTN,MTK,MG=1.2e10,3.5e10,0.75e10,1.0e10   # review Sec.5 mid values; total 6.45e10
RD=2.6
def mw_curve(R,s=1.0,rd=RD):
    vb=hern(R,MB*s,0.7); vd=mn(R,MTN*s,3.0,0.28)+mn(R,MTK*s,3.5,0.9); vg=mn(R,MG*s,7.0,0.1)
    mbar=(MB+MTN+MTK+MG)*s; mstar=(MB+MTN+MTK)*s
    obs={"gas_to_stellar":np.log10(MG*s/mstar),"baryon_compactness":np.log10(mbar/(2*np.pi*(rd*1e3)**2))}
    orig=m._method_c_observable
    m._method_c_observable=lambda g,n,mode,b: obs.get(mode,orig(g,n,mode,b))
    gal=m.SPARCGalaxy(name="MW",radius_kpc=R.copy(),v_obs_kms=np.zeros_like(R),v_err_kms=np.ones_like(R),
        v_gas_kms=np.sqrt(vg),v_disk_kms=np.sqrt(vd/m.DEFAULT_UPSILON_DISK),v_bulge_kms=np.sqrt(vb/m.DEFAULT_UPSILON_BULGE),
        sb_disk_lsun_pc2=np.zeros_like(R),sb_bulge_lsun_pc2=np.zeros_like(R),metadata={"Rdisk":rd})
    v=m.BRANCHES["MC4"].sparc_vcirc_kms(gal,univ,m.GalaxyNuisance())
    m._method_c_observable=orig
    return v,np.sqrt(vb+vd+vg),obs
T=np.loadtxt(S/'run/table1.txt')
Rg=np.array([8.178,10,12.5,15,17.5,20,22.5,25,27.5,30,35,40,45,50,75,100,150,200])
out={"radii_kpc":Rg.tolist(),"curves":{}}
for s in (0.93,1.0,1.25,1.55):
    v,vbar,obs=mw_curve(Rg,s); vt,_,_=mw_curve(T[:,0],s)
    chi=np.sum(((vt-T[:,1])/T[:,2])**2)
    M=lambda R0: float(np.interp(R0,Rg,v))**2*R0/G
    out["curves"][f"Mbar={6.45*s:.2f}e10"]={"v_kms":np.round(v,1).tolist(),"chi2_table1_35pts":round(float(chi),1),
        "M_sph_lt50":M(50),"M_sph_lt100":M(100),"comp_obs":obs["gas_to_stellar"],"morph_obs":obs["baryon_compactness"]}
    print(f"Mbar={6.45*s:5.2f}e10  chi2(35)={chi:6.1f}  M(<50)={M(50):.2e}  M(<100)={M(100):.2e}")
    print("   v:", " ".join(f"{r:g}:{x:.0f}" for r,x in zip(Rg,v)))
# asymptotic Keplerian check
v,_,_=mw_curve(Rg,1.0); sl=np.polyfit(np.log(Rg[-4:]),np.log(v[-4:]),1)[0]; print("dlnV/dlnR 75-200 kpc:",round(sl,3))
json.dump(out,open(S/'out_v7/mw_locked_prediction.json','w'),indent=1)

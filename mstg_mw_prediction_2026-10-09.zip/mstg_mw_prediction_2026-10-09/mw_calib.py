import sys,json,numpy as np
from pathlib import Path
S=Path(sys.argv[1]); exec(open(S/'run/mw_locked.py').read().split("T=np.loadtxt")[0])
T=np.loadtxt(S/'run/table1.txt'); inner=T[:,0]<=15.0; outer=~inner
ss=np.linspace(0.8,1.8,201); chis=[]
for s in ss:
    v,_,_=mw_curve(T[inner,0],s); chis.append(np.sum(((v-T[inner,1])/T[inner,2])**2))
chis=np.array(chis); i=np.argmin(chis); s0=ss[i]; ok=ss[chis<=chis[i]+1]; lo,hi=ok.min(),ok.max()
print(f"inner-disc (R<=15 kpc, {inner.sum()} pts) calibration: Mbar = {6.45*s0:.2f}e10 (1sig {6.45*lo:.2f}-{6.45*hi:.2f}), chi2_in={chis[i]:.1f}")
Rg=np.array([15,17.5,20,22.5,25,27.5,30,35,40,45,50,75,100])
rows={}
for tag,s in (("lo",lo),("best",s0),("hi",hi)):
    v,_,_=mw_curve(Rg,s); rows[tag]=v
vo,_,_=mw_curve(T[outer,0],s0); chi_out=np.sum(((vo-T[outer,1])/T[outer,2])**2)
pulls=(vo-T[outer,1])/T[outer,2]
print(f"PREDICTED outer (R>15, {outer.sum()} pts) vs current data: chi2={chi_out:.1f}; worst pulls:",
      ", ".join(f"R={r:g}:{p:+.1f}" for r,p in sorted(zip(T[outer,0],pulls),key=lambda x:x[1])[:4]))
print(" R(kpc)  v_lo  v_best  v_hi")
for j,r in enumerate(Rg): print(f" {r:6.1f} {rows['lo'][j]:5.0f} {rows['best'][j]:6.0f} {rows['hi'][j]:5.0f}")
G=4.30091e-6
Mm=lambda v,R: v**2*R/G
k50=list(Rg).index(50); k100=list(Rg).index(100)
print(f"M(<50)={Mm(rows['best'][k50],50):.2e} [{Mm(rows['lo'][k50],50):.2e}-{Mm(rows['hi'][k50],50):.2e}]  Orphan-Chenab 3.77(+0.26-0.19)e11")
print(f"M(<100)={Mm(rows['best'][k100],100):.2e} [{Mm(rows['lo'][k100],100):.2e}-{Mm(rows['hi'][k100],100):.2e}]  Sgr 5.6+-0.4e11")
sl=np.polyfit(np.log(Rg[Rg>=20][:7]),np.log(rows['best'][Rg>=20][:7]),1)[0]; print("power-law gamma over 20-50 kpc:",round(sl,3),"(Jiao: -0.47+-0.15 at R>19)")
json.dump({"calibration":{"method":"Mbar scale fit to arXiv:2608.10189 Table 1, R<=15 kpc","Mbar_1e10":[6.45*lo,6.45*s0,6.45*hi]},
  "radii_kpc":Rg.tolist(),"v_lo":np.round(rows['lo'],1).tolist(),"v_best":np.round(rows['best'],1).tolist(),"v_hi":np.round(rows['hi'],1).tolist(),
  "M_lt50":Mm(rows['best'][k50],50),"M_lt100":Mm(rows['best'][k100],100),"gamma_20_50":sl},open(S/'out_v7/mw_calibrated_prediction.json','w'),indent=1)
